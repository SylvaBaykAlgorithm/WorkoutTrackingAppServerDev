package api.dev.WorkApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkAppApplication.class, args);
	}

}
