package api.dev.WorkApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
